// из книжки, типа это best practice, стр 39
(function ($, ){
    $('h1').css('color','cornflowerblue');

    $('#addBtn').on('click', function (){
         /*стр 74 - создание элементов - лучшее решение это JS*/
        const inputValue = $('input').val().trim();

        if (inputValue){
            /*const liElement = $('<li>').text(inputValue);*/ /*исх. вариант*/

            // Хочу первую букву жирненькую, красненькую, в верхнем регистре
            const liElement = $('<li>').text(inputValue);
            const boldFirstChar = $('<b>').text(inputValue.charAt(0).toUpperCase()).css('color', 'red');
            liElement.text(''); // Clear the text content
            liElement.append(boldFirstChar, inputValue.slice(1)); // Add bold first char and remaining text
            //------------

            const newBtnDelete = $('<button>X</button>');
            newBtnDelete.css({'color': 'red', 'border': '2px solid brown', 'margin': '3px 15px', 'box-shadow': 'inset 0px 0px 10px rgba(0,0,0,0.5)'
            });

            newBtnDelete.click(function() {
                $(this).parent().remove();
            });

            $(".itemOl").append(liElement);
            liElement.append(newBtnDelete);

            $('input').val('');
        }
    })

})(jQuery);
