const h1Style = document.querySelector('h1');
const itemOl = document.querySelector('.itemOl');
const btnAdd = document.querySelector('#addBtn');
const input = document.querySelector('input');

h1Style.setAttribute('style', 'color: cornflowerblue;');

btnAdd.onclick = () => {
    if (input.value.trim() === '')
        return;

    //li
    const newLi = document.createElement('li');
    newLi.textContent = input.value;
    itemOl.appendChild(newLi);
    input.value = '';

    //btn delete
    const newBtnDelete = document.createElement('button');
    setStyleButtonDel(newBtnDelete);

    newLi.appendChild(newBtnDelete);
    newBtnDelete.onclick = (e)=>
    {
        e.target.parentElement.remove();
    }

}

function setStyleButtonDel(btnDel){
    btnDel.textContent = 'X';
    btnDel.style.color = 'red';
    btnDel.style.border = '2px solid black';
    btnDel.style.margin = '5px';
}


/* Версия Юлии
*const input = document.querySelector('#item');
const addItem = document.querySelector('#addItem');
const listItems = document.querySelector('#todoList');

addItem.onclick = function (e)
{
    if (input.value)
    {
       let li = document.createElement('li');
       let del = document.createElement('button');
       del.className = 'del';
       del.append(document.createTextNode('X'));
       del.onclick = function (e)
       {
           e.target.parentElement.remove();
       }
       li.append(document.createTextNode(input.value.trim()), del);
       listItems.append(li);
       input.value = '';
    }
}
* */