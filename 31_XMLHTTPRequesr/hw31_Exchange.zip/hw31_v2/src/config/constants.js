const base_url = 'https://api.apilayer.com/';
//const api_key = 'PoUvW3Hb00VBiSiKvA2Y9k9Ax54qjSdi';
const api_key = 'qK5Z4tkoaLvXfNVu1DePCtQhf4xWmJZO';

const myHeaders = new Headers();
myHeaders.append("apikey", api_key);

const requestOptions = {
    method: 'GET',
    redirect: 'follow',
    headers: myHeaders
};

const currencyArray = ['ILS', 'USD', 'EUR', 'UAH', 'RUB'];

export {base_url, api_key, currencyArray, myHeaders, requestOptions}