export const formCurrencyExchange = `
    <div class="row">
        <div class="col-11"></div>
        <div class="col-1">
            <button type="button" class="btn btn-outline-info" id="btnGetCurr" style=" font-size:0.8em ;">Get from server</button>
        </div>
    </div>
    
    <form>
            <div class="form-group text-center font-weight-bold">
                <label>From</label>
                <select name="fromValue" id="fromValue" class="form-control" required>
                    <!--<option value="" disabled selected>- Select currency -</option>-->
                </select>
            </div>

            <div class="form-group text-center font-weight-bold">
                <label>To</label>
                <select name="toValue" id="toValue" class="form-control" required>
                    <!--<option value="" disabled selected>- Select currency -</option>-->
                </select>
            </div>

            <div class="form-group text-center font-weight-bold">
                <label>Sum</label>
                <input type="number" id="sum" class="form-control" step="50" value="100" required>
            </div>

            <button type="submit" class="btn btn-primary" id="btnCalculate">Calculate</button>

            <div class="form-group text-center font-weight-bold">
                <h2 id="result" >Result: 0</h2>
            </div>
    </form>  `;