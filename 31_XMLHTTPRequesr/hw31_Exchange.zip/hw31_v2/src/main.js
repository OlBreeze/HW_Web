import CurrencyExchangeForm from "./ui/CurrencyExchangeForm";
import FormHandler from "./utils/FormHandler";
import {executeQuery} from "./utils/requests";

new CurrencyExchangeForm('.container');
const formHandler = new FormHandler("form");

formHandler.addHandler( () => {
    const selectFromElement = document.querySelector('#fromValue');
    const selectToElement   = document.querySelector('#toValue');
    const labelResult       = document.querySelector('#result');

    let fromLet = selectFromElement.value;
    let toLet = selectToElement.value;
    let amount = document.querySelector('#sum').value;

    executeQuery(`exchangerates_data/convert?to=${toLet}&from=${fromLet}&amount=${amount}`)
        .then(data => {
            //console.log(data);
            if (data.ok||data.success){
                labelResult.textContent = `Result: ${amount} ${fromLet} -> ${data.result} ${toLet}`;}
            else
                labelResult.textContent = "Result: " + data.errorStr;
        })
        .catch(error => {
            labelResult.textContent = "Error: " + error;
        });



})