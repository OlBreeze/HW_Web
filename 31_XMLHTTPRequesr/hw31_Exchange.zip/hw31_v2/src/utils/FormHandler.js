export default class FormHandler{

    constructor(selector) {
        this.$formElement = $(selector); // сокращ запись в jquery по подключению селектора элемента
    }

    addHandler = whatMustDoWithObject => this.$formElement.on('submit', event =>{
        event.preventDefault(); // submit отправляет данные и перегружает форму, отменяем
        let obj = {};
        this.$formElement.serializeArray().forEach(elem => obj[elem.name] = elem.value);
        //serializeArray делит объекты формы на объекты со значением атрибута name в name и атрибута value в value
        let res = whatMustDoWithObject(obj);
        if (res){
            alert(res);
            return;
        }
        event.target.reset();
    })

}