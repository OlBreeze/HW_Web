import {formCurrencyExchange} from "../config/formHTML";
import {currencyArray} from "../config/constants";
import {executeQuery} from "../utils/requests";

export default class CurrencyExchangeForm{
    #parentForm;
    #selectFromCurrency;
    #selectToCurrency;
    #loadFromServer;
    #arrayCurrencyWork;
    #arrayCurrencyServer;

    constructor(selector) {
        this.#loadFromServer = false;

        this.#arrayCurrencyServer = ['AZN','ALL'];  // get from server
        this.setArrayCurrency();

        this.#parentForm = document.querySelector(selector);
        this.#parentForm.innerHTML = formCurrencyExchange;

        this.#selectFromCurrency = document.querySelector('#fromValue');
        this.#selectToCurrency   = document.querySelector('#toValue');

        this.setSelectsCurrency();

        //-- кнопка получения с сервера
        const btnGetCurrencyServer = document.querySelector('#btnGetCurr');
        btnGetCurrencyServer.onclick = ()=>{
            if (!this.#loadFromServer) {
            executeQuery('exchangerates_data/symbols')
                .then(data=> {
                    if (data.ok||data.success)
                        this.fillArrayCurrencyFromServer(data.symbols)
                    else
                        alert(data.errorStr)}
                    )
                .catch(reject => {
                    alert(`There is an Error: ${reject}`)});
            } else alert("It's OK");
        };
    }

    setArrayCurrency() {
        this.#arrayCurrencyWork = this.#loadFromServer?  this.#arrayCurrencyServer: currencyArray;
    }

    setSelectsCurrency() {
        let listCurr = `<option value="" disabled selected>- Select currency -</option>
                ${this.#arrayCurrencyWork.map(cur => `<option value="${cur}">${cur}</option>`)}`;

        this.#selectFromCurrency.innerHTML = listCurr;
        this.#selectToCurrency.innerHTML   = listCurr;

    }

    fillArrayCurrencyFromServer(data){
        this.#arrayCurrencyServer = Object.keys(data);
        this.#loadFromServer = true;
        this.setArrayCurrency();
        this.setSelectsCurrency();
    }
    
}
