(
    function ()
    {
        let App = window.App;

        const orders = new App.Orders();
        const random = new App.Random();
        const generator = new App.OrderGenerator(random);
        const list = new App.List('ol');

        for(let i=0; i<10; i++)
        {
            orders.add(generator.getRandomOrder());
        }
        // console.log(orders.getAll());

        orders.getAll().forEach(function (order)
        {
            list.addItem(JSON.stringify(order));
        })
    }
)()

//ui (user interface)
//service
//config
//utils
//controller