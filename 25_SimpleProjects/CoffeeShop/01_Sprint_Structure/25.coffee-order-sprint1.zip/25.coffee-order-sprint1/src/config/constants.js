const coffeeName = ['cappuccino', 'latte', 'espresso', 'americano', 'mocha', 'instant'];
const size = ['small', 'normal', 'large'];
const flavor = ['lemon', 'cinnamon', 'cardamon', 'milk', 'cognac', 'vanilla'];
const domainName = ['mail.ru', 'gmail.com', 'co.il'];