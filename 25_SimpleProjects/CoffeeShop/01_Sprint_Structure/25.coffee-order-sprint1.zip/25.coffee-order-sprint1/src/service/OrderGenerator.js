(
    function ()
    {
        let App = window.App || {};

        function OrderGenerator(random)
        {
            this.random = random;
        }

        OrderGenerator.prototype.getRandomOrder = function ()
        {
            let email = `name${this.random.getRandomNumber(1, 1000)}@${this.random.getRandomElement(domainName)}`;
            let coffee = this.random.getRandomElement(coffeeName);
            let sizeElement = this.random.getRandomElement(size);
            let flavorElement = this.random.getRandomElement(flavor);
            let strength = this.random.getRandomNumber(0, 100);

            return {email, coffeeName: coffee, size: sizeElement, flavor: flavorElement, strength};
        }

        App.OrderGenerator = OrderGenerator;
        window.App = App;
    }
)()