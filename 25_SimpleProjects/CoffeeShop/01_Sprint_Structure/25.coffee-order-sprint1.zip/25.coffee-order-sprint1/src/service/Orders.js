(
    function ()
    {
        let App = window.App || {};

        function Orders()
        {
            this.data = {};
        }

        Orders.prototype.add = function (order)
        {
            if(this.data[order.email])
                return `Order with email ${order.email} is already exists`;

            this.data[order.email] = order;
            return '';
        }

        Orders.prototype.remove = function (email)
        {
            if(!this.data[email])
                return false;
            delete this.data[email];
            return true;
        }

        Orders.prototype.get = function (email)
        {
            return this.data[email];
        }

        Orders.prototype.getAll = function ()
        {
            return Object.values(this.data);
        }

        App.Orders = Orders;
        window.App = App;
    }
)()
// {email: {coffeeInfo}}