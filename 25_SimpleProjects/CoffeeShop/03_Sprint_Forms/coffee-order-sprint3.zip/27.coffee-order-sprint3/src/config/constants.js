const size = ['small', 'normal', 'large'];
const flavor = ['lemon', 'cinnamon', 'cardamon', 'milk', 'cognac', 'vanilla'];
export const typeDrink = ['coffee', 'tea', 'juice'];
export const kindDrink =
    {
        coffee: ['cappuccino', 'latte', 'espresso', 'americano', 'mocha', 'instant'],
        tea: ['black', 'red', 'green'],
        juice: ['tomato', 'apple', 'orange', 'grape', 'berry']
    };

export {size, flavor};