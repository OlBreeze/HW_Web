export default class FormHandler
{
    constructor(selector)
    {
        this.$formElement = $(selector);
    }

    addHandler = whatMustToDoWithObject => this.$formElement.on('submit', event =>
    {
        event.preventDefault();
        let obj = {};
        this.$formElement.serializeArray().forEach(elem => obj[elem.name] = elem.value);
    //     [{name: coffee, value: instant}, {name: options, value: vanilla}]
        let res = whatMustToDoWithObject(obj);
        if(res)
        {
            alert(res);
            return;
        }
        event.target.reset();
    })
}

// function addHandler(fn)
// {
//     this.$formElement.on('submit', function (event)
//     {
//         event.preventDefault();
//         let obj = {};
//         this.$formElement.serializeArray().forEach(function (elem)
//         {
//             return obj[elem.name] = elem.value;
//         });
//         //     [{name: coffee, value: instant}, {name: options, value: vanilla}]
//         fn(obj);
//     })
// }
//obj[coffee] -> obj.name    obj['my name']   obj[1+1-39]
//obj {coffee: instant, options: vanilla}