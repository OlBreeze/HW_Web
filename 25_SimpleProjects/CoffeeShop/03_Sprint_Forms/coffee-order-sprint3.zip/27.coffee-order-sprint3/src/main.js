import Orders from "./service/Orders";
import List from "./ui/List";
import FormHandler from "./utils/FormHandler";
import OrderForm from "./ui/OrderForm";

const orders = new Orders();
const list = new List('ol');
const formHandler = new FormHandler('form');
new OrderForm('form');


const whatMustToDoWithObject = function (obj)
{
    let res = orders.add(obj);
    if(res)
        return res;
    list.addItem(JSON.stringify(obj));
    console.log(orders.getAll());
}

formHandler.addHandler(whatMustToDoWithObject);