import {flavor, kindDrink, typeDrink} from "../config/constants";

export default class OrderForm
{
    #parentForm;
    #typeOfDrink;
    #kindOfDrink;
    #options;

    constructor(selector)
    {
        this.#parentForm = document.querySelector(selector);
        this.#parentForm.innerHTML =
            `<div>
                <label>Email</label>
                <input type="email" name="email" placeholder="name@co.il" class="form-control" required>
            </div>
            <div>
                <label>Type of drink</label>
                <select class="form-control" required name="type">
                    
                </select>
            </div>
            <div>
                <label>Kind of drink</label>
                <select name="kind" class="form-control" required>
                    
                </select>
            </div>
            <div class="form-check">
                <input type="radio" name="size" class="form-check-input" value="small">
                <label>small</label>
            </div>
            <div class="form-check">
                <input type="radio" name="size" class="form-check-input" checked value="normal">
                <label>normal</label>
            </div>
            <div class="form-check">
                <input type="radio" name="size" class="form-check-input" value="large">
                <label>large</label>
            </div>
            <div>
                <label>Options</label>
                <select name="options" class="form-control">

                </select>
            </div>
            <div>
                <label>Strength</label>
                <input type="range" name="strength" class="form-control" min="0" max="100" step="10" value="50">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
            <button type="reset" class="btn btn-primary">Reset</button>`

        this.#typeOfDrink = document.querySelector('[name="type"]');
        this.#kindOfDrink = document.querySelector('[name="kind"]');
        this.#options = document.querySelector('[name="options"]');

        this.setType();
        this.#typeOfDrink.onchange = () =>
        {
            this.setKind();
            this.setOptions();
            if(this.#typeOfDrink.value === 'juice')
            {
                this.#options.style.display = 'none';
                this.#options.previousElementSibling.style.display = 'none';
            } else
            {
                this.#options.style.display = 'block';
                this.#options.previousElementSibling.style.display = 'block';
            }
        }
    }

    setType()
    {
        this.#typeOfDrink.innerHTML = `<option value="" disabled selected>Select type of drink</option>
        ${typeDrink.map(type => `<option value="${type}">${type}</option>`)}`
    }

    setKind()
    {
        this.#kindOfDrink.innerHTML = `<option value="" disabled selected>Select kind of drink</option>
        ${kindDrink[this.#typeOfDrink.value].map(type => `<option value="${type}">${type}</option>`)}`
    }

    setOptions()
    {
        this.#options.innerHTML = `<option value="" disabled selected>Select options</option>
        ${flavor.map(type => `<option value="${type}">${type}</option>`)}`
    }

}