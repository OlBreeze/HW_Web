import {coffeeName, dn, flavor, size} from "../config/constants";

class OrderGenerator
{
    #random;
    constructor(random)
    {
        this.#random = random;
    }

    getRandomOrder = () =>
    {
        let email = `name${this.#random.getRandomNumber(1, 1000)}@${this.#random.getRandomElement(dn)}`;
        let coffee = this.#random.getRandomElement(coffeeName);
        let sizeElement = this.#random.getRandomElement(size);
        let flavorElement = this.#random.getRandomElement(flavor);
        let strength = this.#random.getRandomNumber(0, 100);

        return {email, coffeeName: coffee, size: sizeElement, flavor: flavorElement, strength};
    }
}

export default OrderGenerator;
