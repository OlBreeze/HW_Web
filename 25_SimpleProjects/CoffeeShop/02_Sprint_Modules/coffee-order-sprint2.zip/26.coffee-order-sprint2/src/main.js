import Orders from "./service/Orders";
import Random from "./utils/Random";
import OrderGenerator from "./service/OrderGenerator";
import List from "./ui/List";

const orders = new Orders();
const random = new Random();
const generator = new OrderGenerator(random);
const list = new List('ol');

for(let i=0; i<10; i++)
{
    orders.add(generator.getRandomOrder());
}

orders.getAll().forEach(function (order)
{
    list.addItem(JSON.stringify(order));
})
