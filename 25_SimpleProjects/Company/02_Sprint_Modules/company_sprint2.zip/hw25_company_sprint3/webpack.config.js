const path = require('path');

module.exports = {
    entry: './src/main.js', // с чего начинаем читать
    output: {           //   куда записать результат
        filename: "bundler.js",
        path: path.resolve(__dirname, 'dist')
    },
    mode: "development"
}