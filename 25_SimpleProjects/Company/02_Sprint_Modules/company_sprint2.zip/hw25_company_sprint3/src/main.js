import Company from "./service/Company";
import Random from "./utils/Random";
import EmployeesGenerator from "./service/employeeGenerator";
import List from "./ui/List";

const company = new Company();
const random = new Random();
const generator = new EmployeesGenerator(random);
const list = new List('ol');

for (let i=0; i<20;i++){
    if(!company.hire(generator.getRandomEmployee())) i--;
}

company.getAll().forEach(function (company){
    list.addItem(JSON.stringify(company));
})
