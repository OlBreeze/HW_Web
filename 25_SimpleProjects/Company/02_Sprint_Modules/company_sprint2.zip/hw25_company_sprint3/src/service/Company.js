export default class Company {
    #data;

    constructor() {
        this.#data = {};
    }

    hire = emloyee => {
        if (this.#data[emloyee.id])
            return false;

        this.#data[emloyee.id] = emloyee;
        return true;
    }

    fire = id => {
        if (!this.#data[id])
            return false;

        delete this.#data[id];
        return true;
    }

    get = id => this.#data[id];

    getAll = () => Object.values(this.#data);

}


