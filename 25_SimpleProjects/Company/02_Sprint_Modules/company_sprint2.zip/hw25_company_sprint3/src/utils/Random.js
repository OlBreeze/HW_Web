export default class Random {
    getRandomNumber = (min, max) => {
        if (min >= max) throw new Error('Max should be greater than min!');
        return min + Math.round(Math.random() * (max - min));
    }

    getRandomElement = array => {
        return array[this.getRandomNumber(0, array.length - 1)];
    }
}

