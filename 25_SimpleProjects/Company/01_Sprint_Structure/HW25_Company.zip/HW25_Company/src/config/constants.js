const gender = ['female', 'male'];
const names  = ['Elizabeth',	'Jacob', 'Joanne',	'Kyle', 'Megan','Joe', 'Victoria',	'Reece', 'Lauren',	'Rhys', 'Michelle',	'Charlie', 'Tracy',	'Damian'];
const titles = ['Wage Employee', 'Manager', 'Sales Person', 'Sales Manager'];
const domainName = ['mail.ru', 'gmail.ru', 'co.il'];