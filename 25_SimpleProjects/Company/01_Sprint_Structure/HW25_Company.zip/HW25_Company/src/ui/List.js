(function (){
    let App = window.App || {};

    function List(selector){
        this.listElement = document.querySelector(selector);
    }

    List.prototype.addItem = function (string){
        let element = document.createElement('li');
        element.textContent = string;
        this.listElement.append(element);
    }

    App.List = List;
    window.App = App;
})()