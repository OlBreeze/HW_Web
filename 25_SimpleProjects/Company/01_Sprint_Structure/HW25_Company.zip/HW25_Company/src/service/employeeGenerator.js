(function () {

    let App = window.App || {};

    function EmployeesGenerator(random) {
        this.random = random;
    }

    EmployeesGenerator.prototype.getRandomEmployee = function () {

        let id = this.random.getRandomNumber(0, 100);
        let email = `${this.random.getRandomNumber(1, 1000)}@${this.random.getRandomElement(domainName)}`;
        let genderElement = this.random.getRandomElement(gender);
        let nameElement = this.random.getRandomElement(names);
        let titleElement = this.random.getRandomElement(titles);
        let salary = this.random.getRandomNumber(1, 1000)*100;

        return {id, email, gender: genderElement, name: nameElement, salary, title: titleElement};

    }
    App.EmployeesGenerator = EmployeesGenerator;
    window.App = App;
})()