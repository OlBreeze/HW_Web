(function (){
    let App = window.App||{};

    function Company(){
        // {<id>:<employee object>}
        this.data = {};
    }

    Company.prototype.hire = function (emloyee){
        if(this.data[emloyee.id])
            return false; // `Emloyee with id ${emloyee.id} is already exists`;

        this.data[emloyee.id] = emloyee;
        return true;
    }

    Company.prototype.fire = function (id){
        if(!this.data[id])
            return false;
        delete this.data[id];
        return true;
    }

    Company.prototype.get = function (id){
        return this.data[id];
    }

    Company.prototype.getAll = function (){
        return Object.values(this.data); // возвращ Массив только значений
    }

    App.Company = Company;
    window.App = App;
})()