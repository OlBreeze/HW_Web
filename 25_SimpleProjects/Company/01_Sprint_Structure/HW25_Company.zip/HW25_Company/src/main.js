(function (){
    let App = window.App;
    const company = new App.Company();
    const random = new App.Random();
    const generator = new App.EmployeesGenerator(random);
    const list = new App.List('ol');

    for (let i=0; i<20;i++){
        if(!company.hire(generator.getRandomEmployee())) i--;
    }

    //console.log(company.getAll());
    company.getAll().forEach(function (company){
        list.addItem(JSON.stringify(company));
    })
})()
