export default class Company {
    #data;
    #count;

    constructor() {
        this.#data = {};
        this.#count = 0;
    }

    hire = employee => {
        if (this.#data[employee.id]) return false;

        this.#data[employee.id] = employee;
        this.#count++;
        return true;
    }

    fire = id => {
        if (!this.#data[id]) return false;

        delete this.#data[id];
        return true;
    }

    get = id => this.#data[id];

    getAll = () => Object.values(this.#data);

    getCount = () => this.#count;
}


