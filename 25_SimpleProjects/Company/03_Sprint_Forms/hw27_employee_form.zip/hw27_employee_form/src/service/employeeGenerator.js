import {cities, countries, domainName, gender, names, titles} from "../config/constants";

export  default class EmployeesGenerator{
    #random;

    constructor(random) {
        this.#random = random;
    }

    getRandomEmployee =  (obj)=> {

        let minId = obj.numberIDdigits * (10**(obj.numberIDdigits-1))/obj.numberIDdigits;
        let maxID = minId*10 - 1;
        let id = this.#random.getRandomNumber(minId, maxID);
        let email = `${this.#random.getRandomNumber(1, 1000)}@${this.#random.getRandomElement(domainName)}`;
        let genderElement = this.#random.getRandomElement(gender);
        let nameElement = this.#random.getRandomElement(names);
        let titleElement = this.#random.getRandomElement(titles);
        let salary = this.#random.getRandomNumber(+obj.minSalary, +obj.maxSalary);
        let country = this.#random.getRandomElement(countries);
        let city = this.#random.getRandomElement(cities[country]);

        return {id, email, gender: genderElement, name: nameElement, salary, title: titleElement, country, city};

    }

    /*getRandomEmpl =  ()=> {

        let id = this.#random.getRandomNumber(0, 100);
        let email = `${this.#random.getRandomNumber(1, 1000)}@${this.#random.getRandomElement(domainName)}`;
        let genderElement = this.#random.getRandomElement(gender);
        let nameElement = this.#random.getRandomElement(names);
        let titleElement = this.#random.getRandomElement(titles);
        let salary = this.#random.getRandomNumber(1, 1000)*100;
        let country = this.#random.getRandomElement(countries);
        let city = this.#random.getRandomElement(cities[country]);

        return {id, email, gender: genderElement, name: nameElement, salary, title: titleElement, country, city};

    }*/
}
