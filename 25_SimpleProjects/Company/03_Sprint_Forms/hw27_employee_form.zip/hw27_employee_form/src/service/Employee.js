export default class Employee{
    #data;

    constructor(data) {
       this.#data = data;
    }

    getObjEmployee(){
        return {
            id: +this.#data.id,
            name:this.#data.name,
            gender: this.#data.gender,
            email: this.#data.email,
            country: this.#data.country,
            city: this.#data.city,
            title: this.#data.title,
            salary: +this.#data.salary,
            }
    }

}

/*{number: '15', minSalary: '8000', numberIDdigits: '2', maxSalary: '80000', id: '5', …}
city: "Melbourne"
country: "Australia"
email: "spisolja@gmail.com"
gender: "on"
id: "5"
maxSalary: "80000"
minSalary: "8000"
name: "Головаш Ольга"
number: "15"
numberIDdigits: "2"
salary: "6000"
title: "Manager*/