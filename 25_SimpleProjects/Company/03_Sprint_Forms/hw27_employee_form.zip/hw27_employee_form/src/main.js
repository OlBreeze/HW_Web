import Company from "./service/Company";
import Employee from "./service/Employee";
import EmployeeForm from "./ui/EmployeeForm";
import EmployeesGenerator from "./service/employeeGenerator";
import GenerationEmployeesForm from "./ui/GenerationEmployeesForm";
import FormHandler from "./utils/FormHandler";
import Random from "./utils/Random";
import List from "./ui/List";


const company = new Company();
const list = new List('ol');

const formEmployee = new EmployeeForm(".createEmployee");
const formGenerationEmployees = new GenerationEmployeesForm( ".generationEmployees");

const formHandlerCreate     = new FormHandler("form.formCreateEmployee");
const formHandlerGeneration = new FormHandler("form.formGenerationEmployees");

//------- Create employee
formHandlerCreate.addHandler(obj => {
    const newEmployee = new Employee(obj);
    if (company.hire(newEmployee.getObjEmployee()))
        list.addItem("" + (company.getCount())  + ". "  + JSON.stringify(newEmployee.getObjEmployee()));
    else return 'Such ID already exists';
    return '';
})

//------- Generation employees
formHandlerGeneration.addHandler(obj => {

    const random = new Random();
    const generator = new EmployeesGenerator(random);

    let k = company.getCount();
    for (let i = 0; i < obj.number; i++) {
        const newEmployee = new Employee(generator.getRandomEmployee(obj));
        if (company.hire(newEmployee.getObjEmployee())) {
            k++;
            list.addItem("" + k  + ". "  + JSON.stringify(newEmployee.getObjEmployee()));
        } else i--;
    }

    return '';
});

//------- events
document.querySelector('.btnGenerationEmployees').addEventListener('click',
    () => {
        formEmployee.setInvisible();
        formGenerationEmployees.setVisible()
    }
)

document.querySelector('.btnCreateEmployee').addEventListener('click',
    () => {
        formEmployee.setVisible();
        formGenerationEmployees.setInvisible()
    }
)

