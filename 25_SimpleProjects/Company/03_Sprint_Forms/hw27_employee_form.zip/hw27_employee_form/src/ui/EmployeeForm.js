import {cities, countries, salaryRange, titles} from "../config/constants";
import {formEmployeeHTML} from "../config/formEmloyeeHTML";

export default class EmployeeForm{
    #parentForm;
    #titles;
    #countries;
    #cities;

    constructor(selector) {

        this.#parentForm = document.querySelector(selector);
        this.#parentForm.innerHTML = formEmployeeHTML;
        this.#titles = document.querySelector('[name = "title"]');
        this.#titles.onchange = () => {
            let minSalary = salaryRange[this.#titles.value][0];
            let maxSalary = salaryRange[this.#titles.value][1];

            const salaryElement = document.querySelector('[name = "salary"]');
            salaryElement.value ='';
            salaryElement.setAttribute("placeholder",  `from ${minSalary} to ${maxSalary}`);
            salaryElement.setAttribute("min", minSalary);
            salaryElement.setAttribute("max", maxSalary);
        }

        this.setTitles();

        this.#countries = document.querySelector('[name = "country"]');
        this.#countries.onchange = () => this.setCities();

        this.#cities = document.querySelector('[name = "city"]');

        this.setCountries();

        this.setInvisible();
    }

    setVisible(){
        this.#parentForm.style.display = 'block';
    }

    setInvisible(){
        this.#parentForm.style.display = 'none';
    }

    setTitles()
    {
        this.#titles.innerHTML = `<option value="" disabled selected>- Select title -</option>
        ${titles.map(type => `<option value="${type}">${type}</option>`)}`
    }

    setCountries()
    {
        this.#countries.innerHTML = `<option value="" disabled selected>- Select country -</option>
        ${countries.map(type => `<option value="${type}">${type}</option>`)}`
    }

    setCities() {
        this.#cities.innerHTML = `<option value="" disabled selected>- Select city -</option>
        ${cities[this.#countries.value].map(type => `<option value="${type}">${type}</option>`)}`
    }
}