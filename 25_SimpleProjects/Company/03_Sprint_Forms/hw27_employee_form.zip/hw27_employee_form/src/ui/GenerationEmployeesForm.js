import {formGenerationEmloyeesHTML} from "../config/formGenerationEmloyeesHTML";

export default class GenerationEmployeesForm{
    #parentForm;

    constructor(selector) {
        this.#parentForm = document.querySelector(selector);
        this.#parentForm.innerHTML = formGenerationEmloyeesHTML;
        this.setInvisible();
    }

    setVisible(){
            this.#parentForm.style.display = 'block';
    }

    setInvisible(){
        this.#parentForm.style.display = 'none';
    }
}