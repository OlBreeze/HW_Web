export const formEmployeeHTML = `
        <header class="card-header text-center">
             <h1>Employee Data</h1>
        </header>
             
        <form class="card-body formCreateEmployee">
            <div class="row">
                <div class="col">
                    <div class="form-group text-center font-weight-bold">
                        <label>Employee Identifier</label>
                        <input type="number" name="id" class="form-control" min="0" max="100000" required>
                    </div>

                    <div class="form-group text-center font-weight-bold">
                        <label>Employee's Name</label>
                        <input type="text" name="name" class="form-control" placeholder="name" required>
                    </div>

                    <div class="form-group text-center font-weight-bold">
                        <label>Title</label>
                        <select name="title" class="form-control" required>
                        </select>
                    </div>

                    <div class="form-group text-center font-weight-bold">
                        <label>Country</label>
                        <select name="country" class="form-control" required>
                        </select>
                    </div>
                </div>

                <div class="col">
                    <div class="form-group text-center font-weight-bold">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control" id="empEmail" required>
                    </div>

                    <div class="form-group font-weight-bold">
                        <label>Gender</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    <input type="radio" name="gender" value="female" required>
                                </div>
                            </div>
                            <label class="form-control">Female</label>

                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    <input type="radio" name="gender" value="male">
                                </div>
                            </div>
                            <label class="form-control">Male</label>
                        </div>
                    </div>

                    <div class="form-group text-center font-weight-bold">
                        <label>Salary</label>
                        <input type="number" name="salary" class="form-control" required>
                    </div>

                    <div class="form-group text-center font-weight-bold">
                        <label>City</label>
                        <select name="city" class="form-control" required>
                                <option value="" disabled selected>- Select city -</option>
                        </select>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
            <button type="reset" class="btn btn-primary">Reset</button>
        </form>`;