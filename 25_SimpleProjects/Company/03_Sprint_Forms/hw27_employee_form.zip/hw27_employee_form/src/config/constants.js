const gender = ['female', 'male'];
const countries = ['Israel', 'Germany', 'France', 'Australia' , 'Canada'];
const names  = ['Elizabeth',	'Jacob', 'Joanne',	'Kyle', 'Megan','Joe', 'Victoria',	'Reece', 'Lauren',	'Rhys', 'Michelle',	'Charlie', 'Tracy',	'Damian'];
const titles = ['Cleaner', 'Manager', 'Programmer', 'Salesman'];
const domainName = ['mail.ru', 'gmail.ru', 'co.il'];

export {gender, names, titles, countries, domainName};

export const salaryRange = {
    Cleaner: [3000, 5000],
    Manager: [6000, 60000],
    Salesman:[5000, 50000],
    Programmer:[10000, 70000]
}

export const cities= {
    Israel:  ['Tel Aviv', 'Jerusalem', 'Haifa', 'Afula', 'Eilat'],
    Germany: ['Berlin', 'Hamburg', 'Munich', 'Cologne', 'Frankfurt'],
    France:  ['Paris', 'Marseille', 'Lyon', 'Toulouse', 'Nice'],
    Australia: ['Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide'],
    Canada:  ['Toronto', 'Montreal', 'Vancouver', 'Calgary', 'Ottawa']
}