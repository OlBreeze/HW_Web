export const formGenerationEmloyeesHTML = `
        <header class="card-header text-center">
            <h1>Employees Generation Data</h1>
        </header>
        <form class="card-body formGenerationEmployees">

            <div class="row">
                <div class="col">
                    <div class="form-group text-center font-weight-bold">
                        <label >Number of Employees</label>
                        <input type="number" name="number" class="form-control" min="0" max="50" value="5">
                    </div>

                    <div class="form-group text-center font-weight-bold">
                        <label>Minimal Salary</label>
                        <input type="number" name="minSalary" class="form-control" min="500" max="50000" step="500" value="8000">
                    </div>
                </div>
                <div class="col">
                    <div class="form-group text-center font-weight-bold">
                        <label>Number of ID digits</label>
                        <input type="number" name="numberIDdigits" class="form-control" min="2" max="10" value="2">
                    </div>

                    <div class="form-group text-center font-weight-bold">
                        <label>Maximal Salary</label>
                        <input type="number" name="maxSalary" class="form-control" min="8000" max="200000" step="1000" value="80000">
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
            <button type="reset" class="btn btn-primary">Reset</button>
        </form>
`;